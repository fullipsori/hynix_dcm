package com.skhynix.neesp;

import java.util.Date;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.skhynix.neesp.log.LogManager;
import com.tibco.ftl.FTL;
import com.tibco.ftl.Publisher;
import com.tibco.ftl.Realm;
import com.tibco.ftl.TibProperties;

public class MessageRouter {
	
	private static final LogManager logger = LogManager.getInstance();
	
	public MessageRouter() {
		
	}	
	
	int countValue = 0;	
	public void kafkaProducer() {
		  // create instance for properties to access producer configs   
		  Properties props = new Properties();
		  
		  //Assign localhost id
		  props.put("bootstrap.servers", "192.168.232.133:9192");
		  
		  //Set acknowledgements for producer requests.      
		  props.put("acks", "all");
		  
		  //If the request fails, the producer can automatically retry,
		  props.put("retries", 0);
		  
		  //Specify buffer size in config
		  props.put("batch.size", 16384);
		  
		  //Reduce the no of requests less than 0   
		  props.put("linger.ms", 1);
		  
		  //The buffer.memory controls the total amount of memory available to the producer for buffering.   
		  props.put("buffer.memory", 33554432);
		  Thread.currentThread().setContextClassLoader(null);
		  props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");		     
		  props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		  
		  logger.debug("*************************************");	      
		  logger.debug("1. Creating KafakProducer!!!");
		  Producer<String, String> producer = new KafkaProducer
		     <String, String>(props);
		  logger.debug("2. Producer created successfually!!!");	      
		
		  String topicName = "quickstart-events";
		  
		  logger.debug("*************************************");	      
		  for(int i = 0; i < 10; i++)	    	 
		     producer.send(new ProducerRecord<String, String>(topicName, 
		        Integer.toString(i), String.format("Test Message: 한글처리가 제대로 되는지 확인한다. [%06d]", countValue++)));
		     
		  
		  logger.debug("3. Message sent successfully");
		  logger.debug("*************************************");
		  producer.close();	      
	}
	
	// FTL 메시지 보내기 위한 연관 함수들 및 ftlMessageSender 
    public String getUniqueName(String sampleName) {   
	    if (sampleName != null && !sampleName.isEmpty()){
	        return sampleName + "_" + getCurrentTime();
	    }
	    return "";
	}

	public long getCurrentTime(){
	   Date date = new Date();
	    return date.getTime();
	}
	
    public void ftlMessageSender() {
    	
    	String          sampleName      = "TibFtlSend";
        String          realmService    = "192.168.232.133:8585";
        String          applicationName = "default";
        String          endpointName    = "default";
        Publisher       			pub             = null;
        com.tibco.ftl.Message       msg             = null;
        Realm        			    realm           = null;
        String			            clientName	 	= getUniqueName(sampleName);
    	        
        logger.debug(String.format("#\n# %s\n#\n# %s\n#\n", this.getClass().getName(), FTL.getVersionInformation()));
        logger.debug(String.format("# Client name %s\n", clientName));
        logger.debug("#\n");
        /*
         * A properties object (TibProperties) allows the client application to set attributes (or properties) for an object
         * when the object is created. In this case, set the client label property (PROPERTY_STRING_CLIENT_LABEL) for the 
         * realm connection. 
         */
        try {
	        TibProperties   props = null;
	        props = FTL.createProperties();
	        props.set(Realm.PROPERTY_STRING_CLIENT_LABEL, clientName);
	 
	        /*
	         * Establish a connection to the realm service. Specify a string containing the realm service URL, and 
	         * the application name. The last argument is the properties object, which was created above.
	        
	         * Note the application name (the value contained in applicationName, which is "default"). This is the default application,
	         * provided automatically by the realm service. It could also be specified as null - it mean the same thing,
	         * the default application. 
	         */
	        realm = FTL.connectToRealmServer(realmService, applicationName, props);
	     
	        /* 
	         * It is good practice to clean up objects when they are no longer needed. Since the realm properties object is no
	         * longer needed, destroy it now. 
	         */
	        props.destroy();
	
	        /*
	         * Before a message can be published, the publisher must be created on the previously-created realm. Pass the endpoint 
	         * onto which the messages will be published.
	
	         * In the same manner as the application name above, the value of endpointName ("default") specifies the default endpoint,
	         * provided automatically by the realm service.
	         */
	        pub = realm.createPublisher(endpointName);   
	
	        /* 
	         * In order to send a message, the message object must first be created via a call to createMessage() on realm. Pass the
	         * the format name. Here the format "helloworld" is used. This is a dynamic format, which means it is not defined in the 
	         * realm configuration. Dynamic formats allow for greater flexibility in that changes to the format only require changes 
	         * to the client applications using it, rather than an administrative change to the realm configuration.
	         */
	        msg = realm.createMessage("helloworld");
	
	        /*
	         * A newly-created message is empty - it contains no fields. The next step is to add one or more fields to the message.
	         * setString() method call on previously-created message adds a string field. First, a string field named "type" is added,
	         * with the value "hello".Then a string field named "message" is added with the value "hello world earth".
	         */
	        	
	        /* 
	         * Once the message is complete, it can be sent via send() method call on previously-created publisher. Pass the message 
	         * to be sent.
	         */
	        for(int i=0; i < 5; i++) {
	            String msgText = String.format("Sending 'hello world' message [%06d]", i);
	            msg.setString("type", "hello");
	            msg.setString("message", msgText);	            
	            pub.send(msg);
	            if(i==0) logger.debug("Sending '"+msgText+"'");
	        }
	
	        // Once objects are no longer needed, they should be disposed of - and generally in reverse order of creation.       
	        // First destroy the message.
	        msg.destroy();       
	        // Then Close the Publisher
	        pub.close();
	        // Next close the connection to the realm service.
	        realm.close();
        }catch(Exception ex) {
        	ex.printStackTrace();
        }
    }

}
