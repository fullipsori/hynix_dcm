package dev.nipafx.demo.modules;

public class HelloModularWorld {

	public static void main(String[] args) {
		System.out.println("Hello, modular World!");
	}

}
